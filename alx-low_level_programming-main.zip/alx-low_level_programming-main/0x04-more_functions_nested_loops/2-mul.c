#include "main.h"
#include <stdio.h>

/**
 * mul - Multiply 2 integers.
 * @a: An integer to be multiplied with b
 * @b : An integer to be multipled with a
 * Return: Return the result of the multiplication
 */
int mul(int a, int b)
{
	return (a * b);
}
