My read me file for 0x06-pointers_arrays_strings
