More on Pointers, Arrays and Strings
