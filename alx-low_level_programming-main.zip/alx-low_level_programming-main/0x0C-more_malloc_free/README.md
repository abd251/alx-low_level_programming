# 0x0C-more_malloc_free
## main.h
> Header contains all function prototypes of functions in this project.



``` MANDATORY```

## 0-malloc_checked.c
> A function that allocates memory using ``` malloc ```.
## 1-string_nconcat.c
> A function that concatenates two strings.
## 2-callloc.c
> A function that allocates memory of an array using malloc.
## 3-array_range.c
> A function that creates an array of integers.

```ADVANCED```

## 100-realloc.c
> A function that reallocates a memory block using malloc and free.
# 101-mul.c
> A function that multiplies two positive numbers.

