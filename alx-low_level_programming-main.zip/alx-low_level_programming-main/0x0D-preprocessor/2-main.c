#include <stdio.h>

/**
 * main - preints the name of the file
 *
 * Return: Always 0 (Success)
 */
int main(void)
{
	printf("%s\n", __FILE__);
	return (0);
}
