# c structures and typedef
